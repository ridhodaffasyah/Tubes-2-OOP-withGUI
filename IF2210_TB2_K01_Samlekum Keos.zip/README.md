# Tubes-2-OOP-withGUI

Command:
b : battle
w,a,s,d : jalan
esc (on map) : menu
esc (on inventory) : back to map

Libraries:
JavaFX 16
JUnit 5.4

Sistem Operasi:
Windows 10

Cara Menjalankan:
1. Buka IDE terbaik mu 
2. Masuk ke dalam folder src/sample/
3. jalankan Main.java (kalo di intelliJ klik ijo2 aja auto build auto run ez pz lyfe)
