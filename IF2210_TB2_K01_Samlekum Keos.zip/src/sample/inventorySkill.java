package sample;

public class inventorySkill {
}
