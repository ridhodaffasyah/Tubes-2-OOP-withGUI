package sample;

public class Story {
}
