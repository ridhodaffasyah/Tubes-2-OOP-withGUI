package sample.BackEnd;


public class InventoryException extends Exception{

    public InventoryException(String errMsg){
        super(errMsg);
    }

}
