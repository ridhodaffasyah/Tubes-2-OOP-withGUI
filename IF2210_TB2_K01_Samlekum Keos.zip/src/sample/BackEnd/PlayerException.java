package sample.BackEnd;

public class PlayerException extends Exception{
    public PlayerException(String msg){
        super(msg);
    }
}
