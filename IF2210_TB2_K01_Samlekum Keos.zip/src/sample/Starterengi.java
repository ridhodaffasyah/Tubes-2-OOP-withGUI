package sample;

public class Starterengi {
}
